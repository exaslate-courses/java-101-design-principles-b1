package org.fourdots.patterns.creational.builder.product;

public interface Product {
	String getName();
	
	double getPrice();
	void setPrice(double price);
	
	Product clone();
}