package org.fourdots.patterns.creational.factory.product;

import java.util.ArrayList;
import java.util.List;

public class Bundle extends AbstractProduct implements Product {
    private final double discountPercentage;
    private final List<Product> products;

    public Bundle(String name, List<Product> products, double discountPercentage) {
    	this.name = name;
    	
        this.products = new ArrayList<>(products);
        this.discountPercentage = discountPercentage;

        // Calculate the total price of the bundled products and apply the discount
        double totalProductPrice = products.stream().mapToDouble(Product::getPrice).sum();        
        this.price = totalProductPrice * (1 - (discountPercentage / 100));
    }
    
    //
    public List<Product> getProducts() {
        return products;
    }

    public double getDiscountPercentage() {
        return discountPercentage;
    }

	@Override
	public String toString() {
		return "Bundle [discountPercentage=" + discountPercentage + ", products=" + products + ", "
				+ super.toString() + "]";
	}

	@Override
	public Product clone() {
		// TODO Auto-generated method stub
		return null;
	}
    
    
}
