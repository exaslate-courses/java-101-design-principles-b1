package org.fourdots.patterns.creational.factory.product;

// Part of Abstract Factory pattern
public interface ProductFactory {
    Product createBundle(String name, Product... products);
}