package org.fourdots.patterns.creational.factory;

import org.fourdots.patterns.creational.factory.product.Book;
import org.fourdots.patterns.creational.factory.product.Product;

import org.fourdots.patterns.creational.factory.product.ProductFactory;
import org.fourdots.patterns.creational.factory.product.BundleFactory;

public class OnlineShopping {
	public static void main(String[] args) {
		Product harryPotter1 = new Book.Builder("Harry Potter and the Sorcerer's Stone", 6.98).author("J. K. Rowling")
				.build();
		Product harryPotter2 = new Book.Builder("Harry Potter and the Chamber of Secrets", 6.98).author("J. K. Rowling")
				.build();

		Product hungerGames = new Book.Builder("The Hunger Games", 8.99).author("Suzanne Collins")
				.genre("Young adult fiction, Thriller").build();

		// Create bundle factories with different discount percentages
		ProductFactory bundleFactory10Percent = new BundleFactory(10);
		ProductFactory bundleFactory20Percent = new BundleFactory(20);

		// Create bundles with different discounts
		Product harryPotter = bundleFactory10Percent.createBundle("10% Discount Bundle", harryPotter1,harryPotter2);
		Product comboPack = bundleFactory20Percent.createBundle("20% Discount Bundle", harryPotter1, hungerGames);


		// Singleton ShoppingCart
		ShoppingCart myCart = ShoppingCart.getInstance();
		myCart.addProduct(harryPotter);
		myCart.addProduct(comboPack);

		myCart.displayContents();
		System.out.println("Total: " + myCart.calculateTotal());
	}
}
