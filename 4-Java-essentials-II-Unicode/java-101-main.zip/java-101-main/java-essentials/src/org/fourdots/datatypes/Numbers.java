package org.fourdots.datatypes;

public class Numbers {
	public static final byte MIN_BYTE = Byte.MIN_VALUE;
	public static final short MIN_SHORT = Short.MIN_VALUE;
	public static final int MIN_INT = Integer.MIN_VALUE;
	public static final long MIN_LONG = Long.MIN_VALUE;

	public static final byte MAX_BYTE = Byte.MAX_VALUE;
	public static final short MAX_SHORT = Short.MAX_VALUE;
	public static final int MAX_INT = Integer.MAX_VALUE;
	public static final long MAX_LONG = Long.MAX_VALUE;

	public static void main(String[] args) {
		byte myByte = 65;
		System.out.println("Byte value: " + myByte);

		// myByte = -129; // Type mismatch: cannot convert from int to byte
		// myByte = 128; // Type mismatch: cannot convert from int to byte
		// myByte = null; // Type mismatch: cannot convert from null to byte

		// Minimum values
		System.out.println("Minimum byte value: " + MIN_BYTE);
		System.out.println("Minimum short value: " + MIN_SHORT);
		System.out.println("Minimum int value: " + MIN_INT);
		System.out.println("Minimum long value: " + MIN_LONG);

		// Maximum values
		System.out.println("Maximum byte value: " + MAX_BYTE);
		System.out.println("Maximum short value: " + MAX_SHORT);
		System.out.println("Maximum int value: " + MAX_INT);
		System.out.println("Maximum long value: " + MAX_LONG);
	}
}
