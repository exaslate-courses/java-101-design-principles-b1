package org.fourdots.solid.lsp.bad;

public class RectangleSquareDemo {
    public static void main(String[] args) {
        Rectangle rectangle = new Square();
        rectangle.setWidth(5);
        rectangle.setHeight(4);
        
        // Let's calculate the area. Expecting 20, but area is 16.
        int area = rectangle.getWidth() * rectangle.getHeight();
        System.out.println("Area: " + area);
    }
}