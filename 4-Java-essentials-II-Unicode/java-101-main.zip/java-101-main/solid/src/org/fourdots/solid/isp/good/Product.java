package org.fourdots.solid.isp.good;

public interface Product {
	String getName();
	double getPrice();
}