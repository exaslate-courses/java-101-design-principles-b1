package org.fourdots.solid.dip.good;

import java.io.IOException;
import java.util.List;

public interface CartRepository {
	void save(String filename, List<Product> products) throws IOException;
}
