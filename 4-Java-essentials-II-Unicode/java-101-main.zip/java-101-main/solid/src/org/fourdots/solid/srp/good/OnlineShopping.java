package org.fourdots.solid.srp.good;

import java.util.List;

public class OnlineShopping {

	public static void main(String[] args) {
		Book harryPotter = new Book("Harry Potter and the Sorcerer's Stone", 6.98, "J.K. Rowling",
				"Fantasy literature");	
		Book hungerGames = new Book("The Hunger Games", 8.99, "Suzanne Collins",
				"Young adult fiction, Thriller");			
		Clothing jean = new Clothing("Levi's Boys' 511 Slim Fit Performance Jeans", 32.18, "19", "Resilient Blue");
		
		// Customer browse products and add to cart		
		Order myOrder = new Order();
		myOrder.addToCart(harryPotter);
		myOrder.addToCart(hungerGames);
		myOrder.addToCart(jean);

		// View cart
		List<Product> products = myOrder.getCart();
		for (Product product : products) {
			System.out.println(product);
		}
	}

}
