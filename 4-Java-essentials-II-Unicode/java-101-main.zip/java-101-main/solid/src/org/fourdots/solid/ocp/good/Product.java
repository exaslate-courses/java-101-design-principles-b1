package org.fourdots.solid.ocp.good;

public interface Product {
	String getName();
	double getPrice();
}