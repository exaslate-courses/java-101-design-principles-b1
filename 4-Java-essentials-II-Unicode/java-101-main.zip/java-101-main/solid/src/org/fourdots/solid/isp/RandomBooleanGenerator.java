package org.fourdots.solid.isp;
import java.util.Random;

public class RandomBooleanGenerator {
    public static void main(String[] args) {
        Random random = new Random();
        boolean randomBoolean = random.nextBoolean();
        
        System.out.println("Random Boolean Value: " + randomBoolean);
    }
}
