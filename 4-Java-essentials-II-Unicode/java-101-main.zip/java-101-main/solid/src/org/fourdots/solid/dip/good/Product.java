package org.fourdots.solid.dip.good;

public interface Product {
	String getName();
	double getPrice();
}