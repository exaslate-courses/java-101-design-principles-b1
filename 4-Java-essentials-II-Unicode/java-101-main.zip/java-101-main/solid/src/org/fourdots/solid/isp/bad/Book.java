package org.fourdots.solid.isp.bad;

import java.util.Random;

public class Book extends AbstractProduct {
	private String author;
	private String genre;

	// constructor
	public Book(String name, double price, String author, String genre) {
		super(name, price);
		this.author = author;
		this.genre = genre;
	}

	// Assume some logic is available
	Random random = new Random();

	public boolean isAvailable() {
		return random.nextBoolean();
	}

	// Methods
	@Override
	public String toString() {
		return "Book [author=" + author + ", genre=" + genre + ", " + super.toString() + "]";
	}

	// getters and setters
	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}
}
