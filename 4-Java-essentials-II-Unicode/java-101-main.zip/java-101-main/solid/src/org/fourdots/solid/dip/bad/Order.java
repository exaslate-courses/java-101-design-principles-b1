package org.fourdots.solid.dip.bad;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Order {
	// Variables
	private ArrayList<Product> cart = new ArrayList<Product>();

	// Constructors
	public Order() {
		super();
	}

	// Methods
	// BAD SRP and DIP	
	public void save(String filename) throws IOException {
		FileWriter writer = new FileWriter(filename);
		for (Product product : cart) {
			writer.write(product.getName() + ": " + String.valueOf(product.getPrice()) + "\n");
		}		
		writer.close();
	}

	protected double calculateShippingCost() {
		return 10.0;
	}

	public ArrayList<Product> getCart() {
		return cart;
	}

	public void addToCart(Product product) {
		this.cart.add(product);
	}
}
