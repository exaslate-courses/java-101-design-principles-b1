package org.fourdots.solid.isp.good;

public interface InventoryProduct extends Product{
	// New requirement
	boolean isAvailable();
}
