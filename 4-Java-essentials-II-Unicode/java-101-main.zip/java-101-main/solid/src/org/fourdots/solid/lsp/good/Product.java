package org.fourdots.solid.lsp.good;

public interface Product {	
	public String getName();
	public double getPrice();
}
