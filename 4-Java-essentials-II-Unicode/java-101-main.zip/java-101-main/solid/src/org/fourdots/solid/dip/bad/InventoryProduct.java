package org.fourdots.solid.dip.bad;

public interface InventoryProduct extends Product{
	// New requirement
	boolean isAvailable();
}
