# Compile and Run Java Source Code (Lib)

```sh
# Compile and redirect the output class to bin directory
javac -d ./lib/bin -sourcepath ./lib/src ./lib/src/org/x/Math.java

# Run the main class
java -classpath ./lib/bin org.x.Math

# Create a jar file
cd ./lib/bin 
jar cvf Math.jar org/ 

# cvf: These are options for the jar command:
# c: Create a new JAR file.
# v: Verbose mode (optional, shows the progress).
# f: Specifies the name of the JAR file you want to create (MyJarFile.jar in this case).
```

# Compile and Run Java Source Code (App)

```sh
# Compile the app java source file, referring to the library class
javac -d ./app/bin -classpath ./lib/bin -sourcepath ./app/src ./app/src/org/y/MainApp.java

# Run the main class
java -classpath ./lib/bin:./app/bin org.y.MainApp

# Run the main class which refers to jar file
java -classpath ./lib/bin/Math.jar:./app/bin org.y.MainApp
```

