package org.fourdots.solid.dip.bad;

public interface Product {
	String getName();
	double getPrice();
}