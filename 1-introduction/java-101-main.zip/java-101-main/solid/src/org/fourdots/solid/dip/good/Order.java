package org.fourdots.solid.dip.good;

import java.io.IOException;
import java.util.ArrayList;

public class Order {
	// Variables
	private ArrayList<Product> cart = new ArrayList<Product>();
	private CartRepository cartRepository;

	// Constructors
	public Order(CartRepository cartRepository) {
		super();
		this.cartRepository = cartRepository;
	}

	// Methods
	public void save(String filename) throws IOException {
		cartRepository.save(filename, cart);
	}

	protected double calculateShippingCost() {
		return 10.0;
	}

	public ArrayList<Product> getCart() {
		return cart;
	}

	public void addToCart(Product product) {
		this.cart.add(product);
	}
}
