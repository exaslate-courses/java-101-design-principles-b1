package org.fourdots.solid.ocp.good;

public class DigitalBook extends AbstractProduct{
	// Variables
	private String author;
	private String genre;

	// Constructor
	public DigitalBook(String name, double price, String author, String genre) {
		super(name, price);
		this.author = author;
		this.genre = genre;
	}
	
	// Methods
	@Override
	public String toString() {
		return "DigitalBook [author=" + author + ", genre=" + genre + ", " + super.toString() + "]";
	}	
	
	// Getters and Setters
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
}
