# Online Shopping

## Initial Use Cases

- Two types of products are available
	- Books
	- Clothing
- Customer browses products
- Customer adds products to their cart
- Customer checks out and pays for their order

## Additional Use Cases After Few Months

- NEW category of products - Digital products are included
- Same-day shipping benefit and associated extra shipping cost are included
