package org.fourdots.solid.srp.good;

import java.util.ArrayList;

public class Order {
	// Variables
	private ArrayList<Product> cart = new ArrayList<Product>();

	//	Constructors
	public Order() {
		super();
	}

	//	Methods
	public void addToCart(Product product) {
		this.cart.add(product);
	}

	// Getters and Setters
	public ArrayList<Product> getCart() {
		return cart;
	}

	public void setCart(ArrayList<Product> cart) {
		this.cart = cart;
	}
}
