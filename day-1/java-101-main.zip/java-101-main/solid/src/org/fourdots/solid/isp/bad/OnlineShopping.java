package org.fourdots.solid.isp.bad;

import java.util.List;

public class OnlineShopping {
	public static void main(String[] args) {
		Product harryPotter = new Book("Harry Potter and the Sorcerer's Stone", 6.98, "J.K. Rowling",
				"Fantasy literature");
		Product harryPotterEbook = new DigitalBook("Harry Potter and the Sorcerer's Stone", 6.98, "J.K. Rowling",
				"Fantasy literature");			
		Product hungerGames = new Book("The Hunger Games", 8.99, "Suzanne Collins",
				"Young adult fiction, Thriller");				
		Product jean = new Clothing("Levi's Boys' 511 Slim Fit Performance Jeans", 32.18, "19", "Resilient Blue");
		
		Order myOrder = new Order();
		myOrder.addToCart(harryPotter);
		myOrder.addToCart(harryPotterEbook);
		myOrder.addToCart(hungerGames);
		myOrder.addToCart(jean);

		List<Product> products = myOrder.getCart();
		for (Product product : products) {
			System.out.println(product);
		}
	}

}
