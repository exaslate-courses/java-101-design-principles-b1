package org.fourdots.solid.dip.good;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class CartFileRepository implements CartRepository {
	@Override
	public void save(String filename, List<Product> products) throws IOException {
		FileWriter writer = new FileWriter(filename);
		for (Product product : products) {
			writer.write(product.getName() + ": " + String.valueOf(product.getPrice()) + "\n");
		}
		writer.close();
	}
}
