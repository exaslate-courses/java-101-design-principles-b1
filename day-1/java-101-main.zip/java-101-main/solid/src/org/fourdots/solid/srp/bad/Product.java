package org.fourdots.solid.srp.bad;

public class Product {
	// Variables for common purpose
	private String name;
	private double price;

	// Variables specific to books
	private String author;
	private String genre;

	// Variables specific to clothing
	private String size;
	private String color;
		
	// Constructors
	private Product(String name, double price) {
		super();
		
		this.name = name;
		this.price = price;
	}
	
	// Methods
	public static Product createBook(String name, double price, String author, String genre) {
		Product product = new Product(name,  price);		
		product.author = author;
		product.genre = genre;
				
		return product;		
	}
	
	public static Product createClothing(String name, double price, String size, String color) {
		Product product = new Product(name, price);		
		product.size = size;
		product.color = color;
				
		return product;		
	}
	
	//
	@Override
	public String toString() {
		return "Product [name=" + name + ", price=" + price + ", author=" + author + ", genre=" + genre + ", size="
				+ size + ", color=" + color + "]";
	}
	
	// Getters and Setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

}
