package org.fourdots.solid.srp.bad;

import java.util.List;

public class OnlineShopping {

	public static void main(String[] args) {
		// Available products
		Product harryPotter = Product.createBook("Harry Potter and the Sorcerer's Stone", 6.98, "J.K. Rowling",
				"Fantasy literature");
		Product hungerGames = Product.createBook("The Hunger Games", 8.99, "Suzanne Collins",
				"Young adult fiction, Thriller");		
		Product jean = Product.createClothing("Levi's Slim Fit Jeans", 32.18, "19", "Resilient Blue");

		// Customer browse products and add to cart		
		Order myOrder = new Order();
		myOrder.addToCart(harryPotter);
		myOrder.addToCart(hungerGames);
		myOrder.addToCart(jean);

		// View cart
		List<Product> products = myOrder.getCart();
		for (Product product : products) {
			System.out.println(product);
		}
	}

}
