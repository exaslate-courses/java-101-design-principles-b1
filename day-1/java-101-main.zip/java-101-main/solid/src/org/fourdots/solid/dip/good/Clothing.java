package org.fourdots.solid.dip.good;

import java.util.Random;

public class Clothing extends AbstractProduct implements InventoryProduct{
	// Variables
	private String size;
	private String color;

	// Constructors
	public Clothing(String name, double price, String size, String color) {
		super(name, price);
		this.size = size;
		this.color = color;
	}

	// Methods
	// Assume some logic is available
	Random random = new Random();

	public boolean isAvailable() {
		return random.nextBoolean();
	}

	@Override
	public String toString() {
		return "Clothing [size=" + size + ", color=" + color + ", " + super.toString() + "]";
	}

	// Getters and Setters
	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
}
