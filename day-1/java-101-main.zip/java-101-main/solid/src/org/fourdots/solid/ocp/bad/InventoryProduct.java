package org.fourdots.solid.ocp.bad;

public interface InventoryProduct extends Product{
	// New requirement
	boolean isAvailable();
}
