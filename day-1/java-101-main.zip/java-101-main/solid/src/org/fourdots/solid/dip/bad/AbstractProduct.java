package org.fourdots.solid.dip.bad;

public abstract class AbstractProduct implements Product{
	// Variables
	private String name;
	private double price;
			
	// Constructors
	public AbstractProduct(String name, double price) {
		super();
		this.name = name;
		this.price = price;
	}

	// Methods
	@Override
	public String toString() {
		return "Product [name=" + name + ", price=" + price + "]";
	}
	
	// Getters and Setters
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}	
}
