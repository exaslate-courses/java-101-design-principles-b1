package org.fourdots.patterns.creational.prototype;

import org.fourdots.patterns.creational.prototype.product.Book;
import org.fourdots.patterns.creational.prototype.product.Product;

public class OnlineShopping {
	public static void main(String[] args) {
		Product harryPotter = new Book("Harry Potter and the Sorcerer's Stone", 6.98, "J.K. Rowling",
				"Fantasy literature");
		Product hungerGames = new Book("The Hunger Games", 8.99, "Suzanne Collins", "Young adult fiction, Thriller");
		
		// Prototype pattern
		Product hungerGames2 = hungerGames.clone();
		hungerGames2.setPrice(9.99);

		// Singleton ShoppingCart
		ShoppingCart myCart = ShoppingCart.getInstance();
		myCart.addProduct(harryPotter);
		myCart.addProduct(hungerGames);
		myCart.addProduct(hungerGames2);
		
		myCart.displayContents();		
		System.out.println("Total: " + myCart.calculateTotal());
	}	
}
