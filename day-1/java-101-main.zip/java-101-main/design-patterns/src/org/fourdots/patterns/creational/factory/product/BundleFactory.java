package org.fourdots.patterns.creational.factory.product;

import java.util.List;

// Part of Abstract Factory pattern
public class BundleFactory implements ProductFactory {
    private final double discountPercentage;

    public BundleFactory(double discountPercentage) {
        this.discountPercentage = discountPercentage;
    }

    // Factory Method pattern
    public Product createBundle(String name, Product... products) {
        return new Bundle(name, List.of(products), discountPercentage);
    }
}