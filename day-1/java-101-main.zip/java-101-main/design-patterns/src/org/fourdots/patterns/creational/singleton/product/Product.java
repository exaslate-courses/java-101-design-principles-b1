package org.fourdots.patterns.creational.singleton.product;

public interface Product {
	String getName();
	double getPrice();
}