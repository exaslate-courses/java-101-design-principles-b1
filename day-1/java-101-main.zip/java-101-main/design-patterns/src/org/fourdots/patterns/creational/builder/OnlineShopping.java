package org.fourdots.patterns.creational.builder;

import org.fourdots.patterns.creational.builder.product.Book;
import org.fourdots.patterns.creational.builder.product.Product;

public class OnlineShopping {
	public static void main(String[] args) {
		Product harryPotter = new Book.Builder("Harry Potter and the Sorcerer's Stone", 6.98).build();

		Product hungerGames = new Book.Builder("The Hunger Games", 8.99).author("Suzanne Collins")
				.genre("Young adult fiction, Thriller").build();

		// Singleton ShoppingCart
		ShoppingCart myCart = ShoppingCart.getInstance();
		myCart.addProduct(harryPotter);
		myCart.addProduct(hungerGames);

		myCart.displayContents();
		System.out.println("Total: " + myCart.calculateTotal());
	}
}
