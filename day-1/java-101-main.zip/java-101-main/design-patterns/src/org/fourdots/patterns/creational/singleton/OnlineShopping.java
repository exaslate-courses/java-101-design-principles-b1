package org.fourdots.patterns.creational.singleton;

import org.fourdots.patterns.creational.singleton.product.Book;
import org.fourdots.patterns.creational.singleton.product.Product;

public class OnlineShopping {
	public static void main(String[] args) {
		Product harryPotter = new Book("Harry Potter and the Sorcerer's Stone", 6.98, "J.K. Rowling",
				"Fantasy literature");
		Product hungerGames = new Book("The Hunger Games", 8.99, "Suzanne Collins",
				"Young adult fiction, Thriller");				

		// Singleton ShoppingCart
		ShoppingCart myCart = ShoppingCart.getInstance();
		myCart.addProduct(harryPotter);
		myCart.addProduct(hungerGames);
		myCart.displayContents();
		System.out.println("Total: " + myCart.calculateTotal());
	}
}
