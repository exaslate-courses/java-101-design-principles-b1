package org.fourdots.patterns.creational.builder.product;

public abstract class AbstractProduct implements Product {
	// Variables
	protected String name;
	protected double price;

	// Constructors
	public AbstractProduct(String name, double price) {
		super();
		this.name = name;
		this.price = price;
	}

	// Methods	
    public abstract Product clone();
		
	@Override
	public String toString() {
		return "Product [name=" + name + ", price=" + price + "]";
	}

	// Getters and Setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
}
