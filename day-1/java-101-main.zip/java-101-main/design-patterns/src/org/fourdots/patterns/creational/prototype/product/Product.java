package org.fourdots.patterns.creational.prototype.product;

public interface Product {
	String getName();
	
	double getPrice();
	void setPrice(double price);
	
	Product clone();
}