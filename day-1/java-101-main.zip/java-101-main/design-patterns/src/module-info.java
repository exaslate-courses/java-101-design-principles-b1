/**
 * 
 */
/**
 * 
 */
module DesignPatterns {
}