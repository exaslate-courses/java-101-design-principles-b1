/**
 * 
 */
/**
 * 
 */
module FunctionalProgramming {
}