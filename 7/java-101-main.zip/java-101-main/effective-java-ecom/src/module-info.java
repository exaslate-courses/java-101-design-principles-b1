/**
 * 
 */
/**
 * 
 */
module EffectiveJavaEcom {
}