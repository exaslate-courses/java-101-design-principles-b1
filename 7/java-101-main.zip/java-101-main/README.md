# Environment Setup

```sh
sdk list java
sdk install java 17.0.8-amzn
sdk default java 17.0.8-amzn
# sdk install java 11.0.20-amzn
# sdk install java 21-amzn

sdk home java 17.0.8-amzn
```