/**
 * 
 */
/**
 * 
 */
module EffectiveJava {
}