package effectivejava.chapter5.item29;

public class EmptyStackException extends RuntimeException {
}
