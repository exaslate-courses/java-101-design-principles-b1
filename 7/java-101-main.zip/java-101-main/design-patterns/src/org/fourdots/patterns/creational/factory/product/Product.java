package org.fourdots.patterns.creational.factory.product;

public interface Product {
	String getName();
	
	double getPrice();
	void setPrice(double price);
	
	Product clone();
}