package org.fourdots.patterns.creational.prototype;

import java.util.ArrayList;
import java.util.List;

import org.fourdots.patterns.creational.prototype.product.Product;

// Singleton ShoppingCart
class ShoppingCart {
    private static ShoppingCart instance = null;
    private List<Product> products = new ArrayList<>();

    private ShoppingCart() {
        // Private constructor to prevent instantiation
    }

    public static ShoppingCart getInstance() {
        if (instance == null) {
            instance = new ShoppingCart();
        }
        return instance;
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public double calculateTotal() {
        return products.stream().mapToDouble(Product::getPrice).sum();
    }

    public void displayContents() {
        System.out.println("Shopping Cart Contents:");
        for (Product product : products) {
        	System.out.println(product);
        }
    }
}