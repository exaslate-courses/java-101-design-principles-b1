package org.fourdots.patterns.creational.factory.product;

import java.util.Random;

public class Book extends AbstractProduct implements Product{
	// Variables
	private String author;
	private String genre;
	
	// Private Constructors
	private Book(Builder builder) {	
		super(builder.name, builder.price);
		
        this.author = builder.author;
        this.genre = builder.genre;
    }
	
	private Book(String name, double price, String author, String genre) {
		super(name, price);
		this.author = author;
		this.genre = genre;
	}
	
	// Builder Pattern
	public static class Builder {
        private final String name;
        private final double price;        
        private String author;
        private String genre = "";
        
        public Builder(String name, double price) {
            this.name = name;
            this.price = price;
        }
        
        public Builder author(String author) {
            this.author = author;
            return this;
        }

        public Builder genre(String genre) {
            this.genre = genre;
            return this;
        }

        public Book build() {
            return new Book(this);
        }
    }

	// Assume some logic is available
	Random random = new Random();

	public boolean isAvailable() {
		return random.nextBoolean();
	}

	// Methods		
    public Product clone() {
        return new Book(this.name, this.price, this.author, this.genre);
    }

	// Getters and Setters
	public String getAuthor() {
		return author;
	}

	@Override
	public String toString() {
		return "Book [author=" + author + ", genre=" + genre + ", " + super.toString() + "]";
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}
}
