# Online Shopping

## Sprint 1 Use Cases

- Two types of products are available
	- Books
	- Clothing
- Customer browses products
- Customer adds products to their cart
- Customer checks out and pays for their order

## Sprint 2 Use Cases

- Bundle products with specific discount
