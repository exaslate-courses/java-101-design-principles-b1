package org.fourdots.solid.dip.good;

import java.io.IOException;


public class OnlineShopping {
	public static void main(String[] args) {
		InventoryProduct harryPotter = new Book("Harry Potter and the Sorcerer's Stone", 6.98, "J.K. Rowling",
				"Fantasy literature");
		Product harryPotterEbook = new DigitalBook("Harry Potter and the Sorcerer's Stone", 5.25, "J.K. Rowling",
				"Fantasy literature");		
		InventoryProduct hungerGames = new Book("The Hunger Games", 8.99, "Suzanne Collins",
				"Young adult fiction, Thriller");				
		InventoryProduct jean = new Clothing("Levi's Boys' 511 Slim Fit Performance Jeans", 32.18, "19", "Resilient Blue");
		
		CartFileRepository fileRepository = new CartFileRepository(); 
		SameDayShippingOrder myOrder = new SameDayShippingOrder(fileRepository);
		myOrder.addToCart(harryPotter);
		myOrder.addToCart(harryPotterEbook);
		myOrder.addToCart(hungerGames);
		myOrder.addToCart(jean);

		try {
			System.out.println("Save the cart");
			myOrder.save("mycart.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
