package org.fourdots.solid.ocp.good;

import java.util.Random;

public class SameDayShippingOrder extends Order{
	// Constructors
	public SameDayShippingOrder() {
		super();
	}

	// Methods
	// Assume some logic is available
	Random random = new Random();
	boolean sameDayShippingEligible = random.nextBoolean();

	public boolean isEligibleForSameDayShipping() {
		// Check if the order was placed before the same day shipping cutoff time
		// Check if all products are eligible for same day shipping
		// All criteria are met, so the order is eligible for same day shipping
		return sameDayShippingEligible; 
	}

	@Override
	public double calculateShippingCost() {
		// Check if the order is eligible for same day shipping
		if (sameDayShippingEligible) {
			// Calculate the shipping cost for same day shipping
			return 20.0;
		} else {
			// Calculate the shipping cost for standard shipping
			return super.calculateShippingCost();
		}
	}
}
