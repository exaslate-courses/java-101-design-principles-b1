package org.fourdots.solid.ocp.bad;

public interface Product {
	String getName();
	double getPrice();
}