package org.fourdots.solid.isp.good;

import java.util.Random;

public class Book extends AbstractProduct implements InventoryProduct{
	// Variables
	private String author;
	private String genre;

	// Constructor
	public Book(String name, double price, String author, String genre) {
		super(name, price);
		this.author = author;
		this.genre = genre;
	}

	// Assume some logic is available
	Random random = new Random();

	public boolean isAvailable() {
		return random.nextBoolean();
	}

	// Methods

	// Getters and Setters
	public String getAuthor() {
		return author;
	}

	@Override
	public String toString() {
		return "Book [author=" + author + ", genre=" + genre + ", " + super.toString() + "]";
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}
}
