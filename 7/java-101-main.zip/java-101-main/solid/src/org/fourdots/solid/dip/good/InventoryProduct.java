package org.fourdots.solid.dip.good;

public interface InventoryProduct extends Product{
	// New requirement
	boolean isAvailable();
}
