package org.fourdots.solid.isp.bad;

public interface Product {
	String getName();
	double getPrice();

	// New requirement
	// BAD: This method is not supported by all products
	boolean isAvailable();
}