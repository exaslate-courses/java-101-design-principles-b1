package org.fourdots.solid.ocp.good;

import java.util.ArrayList;

public class Order {
	// Variables
	private ArrayList<Product> cart = new ArrayList<Product>();

	// Constructors
	public Order() {
		super();
	}

	// Methods
	protected double calculateShippingCost() {
			return 10.0;
	}

	public ArrayList<Product> getCart() {
		return cart;
	}

	public void addToCart(Product product) {
		this.cart.add(product);
	}
}
