package org.fourdots.solid.ocp.good;

public interface InventoryProduct extends Product{
	// New requirement
	boolean isAvailable();
}
