package org.fourdots.solid.ocp.bad;

import java.util.ArrayList;
import java.util.Random;

public class Order {
	// Variables
	private ArrayList<Product> cart = new ArrayList<Product>();

	// Constructors
	public Order() {
		super();
	}

	// Methods

	// NEW Methods are added - BAD
	// Assume some logic is available
	Random random = new Random();
	boolean sameDayShippingEligible = random.nextBoolean();

	public boolean isEligibleForSameDayShipping() {
		// Check if the order was placed before the same day shipping cutoff time
		// Check if all products are eligible for same day shipping
		// All criteria are met, so the order is eligible for same day shipping
		return sameDayShippingEligible; 
	}

	public double calculateShippingCost() {
		// Check if the order is eligible for same day shipping
		if (sameDayShippingEligible) {
			// Calculate the shipping cost for same day shipping
			return 20.0;
		} else {
			// Calculate the shipping cost for standard shipping
			return 10.0;
		}
	}

	public ArrayList<Product> getCart() {
		return cart;
	}

	public void addToCart(Product product) {
		this.cart.add(product);
	}
}
