package org.fourdots.solid.isp.bad;

import java.util.ArrayList;

public class Order {

	private ArrayList<Product> cart = new ArrayList<Product>();

	public ArrayList<Product> getCart() {
		return cart;
	}

	public void addToCart(Product product) {
		this.cart.add(product);
	}

	public Order() {
		super();
	}
}
