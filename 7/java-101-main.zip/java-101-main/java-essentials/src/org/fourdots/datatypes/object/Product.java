package org.fourdots.datatypes.object;

import java.util.Objects;

class Product {
	// attributes
	private int id;
	private String name;

	// constructors
	public Product(int id, String name) {
		this.id = id;
		this.name = name;
	}

	// getters
	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + "]";
	}
		
	@Override
	public boolean equals(Object obj) {		
		if (this == obj)
			return true;
		if (obj == null || getClass() != obj.getClass())
			return false;
		Product product = (Product) obj;
		return id == product.id;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
		
//	    int result = 1;
//	    result = 31 * result + id;
//	    return result;
	}
}
