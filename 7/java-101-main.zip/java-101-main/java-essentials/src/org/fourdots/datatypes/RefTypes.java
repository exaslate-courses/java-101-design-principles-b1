package org.fourdots.datatypes;

public class RefTypes {

	public static void main(String[] args) {
		// Create a reference to a String object
		String originalString = "Hello, World!";

		// Create a reference to the same String object
		String referenceString = originalString;

		// Both references point to the same object in memory
		System.out.println("Original String: " + originalString);
		System.out.println("Reference String: " + referenceString);

		// Modify the contents of the referenceString
		referenceString = referenceString.toUpperCase();

		// Now, referenceString points to a new String object with the modified content
		System.out.println("Original String (after modification): " + originalString);
		System.out.println("Reference String (after modification): " + referenceString);

		// Passing a reference to a method
		modifyString(originalString);

		// After the method call, the content of originalString has been modified
		System.out.println("Original String (after method call): " + originalString);
	}

	public static void modifyString(String str) {
		// Modify the contents of the string passed to the method
		str = str.toLowerCase();
	}
}