package org.fourdots.datatypes.object;

public class ObjectDemo {
	@SuppressWarnings("unlikely-arg-type")
	public static void main(String[] args) {
		Product p1 = new Product(1, "Laptop");
		Product p2 = new Product(2, "Tablet");		
		Product p3 = new Product(1, "Laptop");
		
		ProductV2 p4 = new ProductV2(2, "Tablet");
		
		System.out.println("Class of p1: " + p1.getClass().getName());			
		System.out.println("Class of p4: " + p4.getClass().getName());
		
		//
		System.out.println("\nPrint all products");
		System.out.printf("%s %d\n", p1, p1.hashCode());
		System.out.printf("%s %d\n", p2, p2.hashCode());
		System.out.printf("%s %d\n", p3, p3.hashCode());
		System.out.printf("%s %d\n", p4, p4.hashCode());
			
		//
		System.out.println("\np1 equals p2: " + p1.equals(p2));
		System.out.println("p1 equals p3: " + p1.equals(p3));
		System.out.println("p1 equals p4: " + p1.equals(p4));	
	}
}
