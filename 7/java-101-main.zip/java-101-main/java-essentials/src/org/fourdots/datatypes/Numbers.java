package org.fourdots.datatypes;

public class Numbers {
	static byte myByte;
	static short myShort;
	static int myInt;
	static long myLong;
	
	public static void main(String[] args) {
		// Byte
		System.out.println("Byte default value: " + myByte);
		System.out.println("Minimum byte value: " + Byte.MIN_VALUE);
		System.out.println("Maximum byte value: " + Byte.MAX_VALUE);
		
		// myByte = -129; // Type mismatch: cannot convert from int to byte
		// myByte = 128; // Type mismatch: cannot convert from int to byte
		// myByte = null; // Type mismatch: cannot convert from null to byte
				
		// Short
		System.out.println("\nShort default value: " + myShort);
		System.out.println("Minimum short value: " + Short.MIN_VALUE);
		System.out.println("Maximum short value: " + Short.MAX_VALUE);
		
		// Integer
		System.out.println("\nInt default value: " + myInt);
		System.out.println("Minimum int value: " + Integer.MIN_VALUE);
		System.out.println("Maximum int value: " + Integer.MAX_VALUE);
		
		// Long
		System.out.println("\nLong default value: " + myLong);		
		System.out.println("Minimum long value: " + Long.MIN_VALUE);
		System.out.println("Maximum long value: " + Long.MAX_VALUE);
	}
}
