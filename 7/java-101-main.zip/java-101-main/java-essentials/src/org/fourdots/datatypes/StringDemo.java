package org.fourdots.datatypes;

import java.util.Objects;

public class StringDemo {
	public static void main(String[] args) {
		String laptopA = "Laptop";
		String laptopB = "laptop";
				
		System.out.println(laptopA == laptopB); // false
		System.out.println(laptopA.toUpperCase() == laptopB.toUpperCase()); // false
		System.out.println(laptopA.equals(laptopB)); // false 		
		System.out.println(laptopA.equalsIgnoreCase(laptopB)); // true	
		System.out.println(laptopA.toUpperCase().intern() == laptopB.toUpperCase().intern()); // true	
		System.out.println(Objects.equals(laptopA, laptopB)); // false
	}
}
