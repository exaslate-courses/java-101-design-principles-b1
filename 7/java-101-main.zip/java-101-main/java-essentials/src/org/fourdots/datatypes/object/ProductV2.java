package org.fourdots.datatypes.object;

import java.util.Objects;

class ProductV2 {
	private int id;
	private String name;

	public ProductV2(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}
	
	@Override
	public String toString() {
		return "ProductV2 [id=" + id + ", name=" + name + "]";
	}	

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null || getClass() != obj.getClass())
			return false;
		ProductV2 product = (ProductV2) obj;
		return id == product.id && Objects.equals(name, product.name);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, name);
	}
}
