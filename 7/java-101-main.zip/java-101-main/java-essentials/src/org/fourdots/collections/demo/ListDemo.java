package org.fourdots.collections.demo;

import java.util.ArrayList;
//import java.util.LinkedList;
import java.util.List;

public class ListDemo {
	public static void main(String[] args) {
		Product bookA = new Product(1, "Harry Potter");
		Product bookB = new Product(2, "Hunger Games");
		Product mobileA = new Product(3, "Samsung");
		
		List<Product> cart = new ArrayList<>();

		// Add to Cart	
		cart.add(bookA);	
		cart.add(bookB);					
		cart.add(mobileA);
			
		// View Cart
		System.out.println("Cart at time t1");		
		for (int i = cart.size()-1; i >= 0; i--) {
            Product product = cart.get(i);
            System.out.println("Product " + i + ": " + product);
        }
				
		// Delete
		Product samsung = new Product(3, "Samsung");
		cart.remove(samsung);
		
		// View Cart
		System.out.println("\nCart at time t2");
		for (Product product: cart) {
			System.out.println(product);
		}
	}
}
