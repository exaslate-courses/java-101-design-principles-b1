package org.fourdots.collections.demo;

import java.util.ArrayList;

public class ArrayListDemo {
	public static void main(String[] args) {	
		// Create an ArrayList with an initial capacity of 5
		ArrayList<String> names = new ArrayList<>(5);

		// Add some elements to the ArrayList
		names.add("Alice");
		names.add("Bob");
		names.add("Charlie");
		names.add("David");

		// Check the current size
		System.out.println("Current size of the ArrayList: " + names.size());

		// Now, let's add more elements that will exceed the initial capacity
		names.add("Eve");
		names.add("Frank");

		// Check the size and capacity again before using ensureCapacity
		System.out.println("Current size of the ArrayList: " + names.size());

		// Use ensureCapacity to set a new minimum capacity
		names.ensureCapacity(10);

		// Check the size and capacity after using ensureCapacity
		System.out.println("Current size of the ArrayList: " + names.size());		
	}
}
