package org.fourdots.collections.demo;

import java.util.HashMap;
import java.util.Map;

public class MapDemo {
	public static void main(String[] args) {
		Product bookA = new Product(1, "Harry Potter");
		Product bookB = new Product(2, "Hunger Games");
		Product mobileA = new Product(3, "Samsung1");
		Product mobileB = new Product(3, "Samsung2");

		Map<Integer, Product> catalog = new HashMap<>();
		
		catalog.put(bookA.getId(), bookA);
		catalog.put(bookB.getId(), bookB);

		System.out.println(catalog.put(mobileA.getId(), mobileA));
		System.out.println(catalog.put(mobileB.getId(), mobileB));
		
		System.out.println(catalog.containsKey(3));

		System.out.println("\n");
		for (Map.Entry<Integer, Product> entry : catalog.entrySet()) {
			Product product = entry.getValue();
			System.out.println(product);
		}
	}

}
