package org.fourdots.collections.demo;

import java.util.Arrays;

public class ArrayDemo {
	public static void main(String[] args) {
		// Arrays have a fixed size once they are initialized. 
		String[] products = { "Laptop", "Smartphone", "Headphones"};
		System.out.println(products.length);

		// Loop through the array and print each product name
		for (int i = 0; i < products.length; i++) {
			String product = products[i];
			System.out.println("Product " + i + ": " + product);
		}

		// Add one more product after initialization
		String newProduct = "Smartwatch";

		// Create a new array with the additional product
		products = Arrays.copyOf(products, products.length + 1);
		products[products.length - 1] = newProduct;

		// Loop through the updated array using an enhanced for loop
		System.out.println("\nNew Array");
		for (String product : products) {
			System.out.println("Product: " + product);
		}
	}
}
