package org.fourdots.collections.demo;

import java.util.HashSet;
import java.util.Set;

public class SetDemo {
	public static void main(String[] args) {
		Product bookA = new Product(1, "Harry Potter");
		Product bookB = new Product(2, "Hunger Games");
		Product mobileA = new Product(3, "Samsung1");
		Product mobileB = new Product(3, "Samsung2");

		Set<Product> catalog = new HashSet<>();
		catalog.add(bookA);
		catalog.add(bookB);

		System.out.println(catalog.add(mobileA));
		System.out.println(catalog.add(mobileB));

		//
		for (Product product : catalog) {
			System.out.println(product);
		}

		//
		System.out.println(catalog.contains(mobileB));
	}

}
