package org.fourdots.fp.intro;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class HighOrderFunction {
	public static Predicate<String> checkIfStartsWith(final String letter) {
		return name -> name.startsWith(letter);
	}
	public static List<String> method(final List<String> cities) {
		return cities.stream()
				.filter(checkIfStartsWith("B"))
				.collect(Collectors.toList());
	}

	public static final Function<String, Predicate<String>> startsWithLetter = letter -> name -> name
			.startsWith(letter);
	public static List<String> fnInterface(final List<String> cities) {
		return cities.stream()
				.filter(startsWithLetter.apply("B"))
				.collect(Collectors.toList());
	}

	public static void main(String[] args) {
		final List<String> cities = Arrays.asList("Chennai", "Bangalore", "Coimbatore", "Delhi");

		System.out.println();
		method(cities).forEach(System.out::println);
		
		System.out.println();
		fnInterface(cities).forEach(System.out::println);
	}
}
