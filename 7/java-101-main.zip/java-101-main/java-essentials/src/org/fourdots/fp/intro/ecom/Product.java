package org.fourdots.fp.intro.ecom;

import java.math.BigDecimal;

public class Product {
	private int id;
	private String name;
	private BigDecimal price;
	private boolean inStock;
	
	public Product(int id, String name, BigDecimal price, boolean inStock) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.inStock = inStock;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public boolean isInStock() {
		return inStock;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + ", inStock=" + inStock + "]";
	}	
}
