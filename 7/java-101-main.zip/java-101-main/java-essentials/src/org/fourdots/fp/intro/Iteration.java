package org.fourdots.fp.intro;

import java.util.Arrays;
import java.util.List;

public class Iteration {
	public static void habitual(final List<String> cities) {
		for (int i = 0; i < cities.size(); i++) {
			System.out.println(cities.get(i));
		}
	}

	public static void civilized(final List<String> cities) {	
		for (String city : cities) {
			System.out.println(city);
		}
	}

	public static void functionalStyle(final List<String> cities) {
		// cities.forEach((final String city) -> System.out.println(city));
		// cities.forEach((city) -> System.out.println(city));
		// cities.forEach(city -> System.out.println(city));
		cities.forEach(System.out::println);
	}

	public static void main(String[] args) {
		final List<String> cities = Arrays.asList("Chennai", "Bangalore", "Coimbatore");

		System.out.println("");
		habitual(cities);
		
		System.out.println("");
		civilized(cities);
		
		System.out.println("");
		functionalStyle(cities);		
	}
}
