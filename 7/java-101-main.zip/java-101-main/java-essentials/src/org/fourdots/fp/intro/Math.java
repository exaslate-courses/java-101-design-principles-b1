package org.fourdots.fp.intro;

import java.util.Arrays;
import java.util.List;

public class Math {

	public static void imperativeStyle( ) {
		int[] numbers = {1, 2, 3, 4, 5};
		int sum = 0;
		for (int i = 0; i < numbers.length; i++) {
		    sum += numbers[i];
		}
		System.out.println("Sum: " + sum);
	}
	
	public static void declarativeStyle() {
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
		int sum = numbers.stream()
		                 .reduce(0, (x, y) -> x + y);
		System.out.println("Sum: " + sum);
	}
	
	public static void main(String[] args) {
		imperativeStyle();
		declarativeStyle();
	}

}
