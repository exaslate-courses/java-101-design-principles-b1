package org.fourdots.fp.intro;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Filter {
	public static List<String> imperativeStyle(final List<String> cities) {		
		final List<String> selectedCities = new ArrayList<String>();
		for (String city : cities) {
			if (city.startsWith("C")) {
				selectedCities.add(city);
			}
		}		
		return selectedCities;
	}

	public static List<String> functionalStyle(final List<String> cities) {		
		return cities.stream()
				.filter(city -> city.startsWith("C"))
				.collect(Collectors.toList());
	}

	public static void main(String[] args) {
		final List<String> cities = Arrays.asList("Chennai", "Bangalore", "Coimbatore");

		System.out.println();
		imperativeStyle(cities).forEach(System.out::println);

		System.out.println();
		functionalStyle(cities).forEach(System.out::println);
	}
}
