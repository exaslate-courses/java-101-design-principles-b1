package org.fourdots.fp.intro;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Closure {
	public static List<String> enclosingScope(final List<String> cities, final String filterBy) {
		return cities.stream()
				.filter(name -> name.startsWith(filterBy))
				.collect(Collectors.toList());
	}

//	public static List<String> scopeError(final List<String> cities) {
//		String filterBy = "C";	
//		List<String> selectedCities = cities.stream()
//				.filter(name -> name.startsWith(filterBy))
//				.collect(Collectors.toList());
//		
//		filterBy = "D";
//		return selectedCities;
//	}

	public static void main(String[] args) {
		final List<String> cities = Arrays.asList("Chennai", "Bangalore", "Coimbatore", "Delhi");
		enclosingScope(cities, "C").forEach(System.out::println);
	}
}
