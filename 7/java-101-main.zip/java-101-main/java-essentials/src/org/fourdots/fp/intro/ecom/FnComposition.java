package org.fourdots.fp.intro.ecom;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class FnComposition {
	public static boolean isInStock(Product product) {
		System.out.println("isInStock >> " + product.getName());
		return product.isInStock();
	}

	public static Predicate<Product> isPriceLessThan(final BigDecimal price) {
		return product ->
			{
				System.out.println("isPriceLessThan >> " + product.getPrice());
				return product.getPrice()
						.compareTo(price) < 0;
			};
	}

	public static final Predicate<Product> isPriceLessThan100 = isPriceLessThan(BigDecimal.valueOf(100));

	public static void main(String[] args) {
		List<Product> products = Arrays.asList(new Product(3, "Mobile", new BigDecimal("100.65"), true),
				new Product(1, "BookA", new BigDecimal("10.23"), true),
				new Product(2, "BookB", new BigDecimal("20.54"), false),
				new Product(4, "Food", new BigDecimal("5.30"), true));

		// Find high price under $100 and in-stock
		System.out.println(products.stream()
				.filter(isPriceLessThan100)
				.filter(FnComposition::isInStock)
				.findFirst()
				.orElse(null));
	}
}
