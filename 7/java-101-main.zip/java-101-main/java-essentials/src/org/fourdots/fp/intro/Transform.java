package org.fourdots.fp.intro;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Transform {
	public static List<String> imperativeStyle(final List<String> cities) {		
		final List<String> ucCities = new ArrayList<String>();
		for (String city : cities) {
			ucCities.add(city.toUpperCase());
		}
		return ucCities;
	}

	public static List<String> nonFunctionalStyle(final List<String> cities) {		
		final List<String> ucCities = new ArrayList<String>();
		cities.forEach(city -> ucCities.add(city.toUpperCase()));		
		return ucCities;
	}

	public static List<String> functionalStyle(final List<String> cities) {
		return cities.stream()
				.map(city -> city.toUpperCase())
				.toList();		
	}

	public static void main(String[] args) {
		final List<String> cities = Arrays.asList("Chennai", "Bangalore", "Coimbatore");

		System.out.println();
		imperativeStyle(cities).forEach(System.out::println);

		System.out.println();
		nonFunctionalStyle(cities).forEach(System.out::println);

		System.out.println();
		functionalStyle(cities).forEach(System.out::println);
	}

}
