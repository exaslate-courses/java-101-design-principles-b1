package org.fourdots.datatypes;

public class Emoji {
	public static void main(String[] args) {
		// https://www.unicode.org/emoji/charts/emoji-list.html
		// https://en.wikibooks.org/wiki/Unicode/Character_reference/1F000-1FFFF
		int runningPerson = 0x1F3C3;
		int zeroWidthJoiner = 0x200D;
		int femaleSign = 0x2640;
		int variationSelector = 0xFE0F;

		// String runningPersonEmoji = "🏃"; // Running Person
		String runningPersonEmoji = new String(Character.toChars(runningPerson));
		System.out.println(runningPersonEmoji);

		// Combine the code points to create the emoji
		int[] emojiCodePoints = { runningPerson, zeroWidthJoiner, femaleSign, variationSelector };

		// Create a string from the code points
		String emoji = new String(emojiCodePoints, 0, emojiCodePoints.length);
		System.out.println(emoji);
	}
}
