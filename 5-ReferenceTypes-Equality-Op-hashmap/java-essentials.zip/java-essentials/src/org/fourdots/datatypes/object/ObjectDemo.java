package org.fourdots.datatypes.object;

public class ObjectDemo {

	public static void print(Object obj1, Object obj2, Object obj3) {
		// Using toString()
		System.out.println("\nUsing toString():");
		System.out.println(obj1);
		System.out.println(obj2);
		System.out.println(obj3);
	}

	public static void compare(Object p1, Object p2, Object p3) {
		// Using equals()
		System.out.println("\nUsing equals():");
		System.out.println("p1 equals p2: " + p1.equals(p2));
		System.out.println("p1 equals p3: " + p1.equals(p3));
	}

	public static void printHashCode(Object p1, Object p2, Object p3) {
		// Using hashCode()
		System.out.println("\nUsing hashCode():");
		System.out.println("HashCode of p1: " + p1.hashCode()); 
		System.out.println("HashCode of p2: " + p2.hashCode()); 
		System.out.println("HashCode of p3: " + p3.hashCode()); 		
	}

	public static void main(String[] args) {
		Product product1 = new Product(1, "Laptop");
		Product product2 = new Product(2, "Tablet");
		
		Product product3 = new Product(1, "Laptop");		
		System.out.println("Class of product1: " + product1.getClass().getName());
		
		ProductV2 product4 = new ProductV2(3, "Mobile");		
		System.out.println("Class of product1: " + product4.getClass().getName());
		
		//
		print(product1, product2, product3);
		compare(product1, product2, product3);
		printHashCode(product1, product2, product3);
				
		//
		compare(product1, product2, product4);
		
	}
}
