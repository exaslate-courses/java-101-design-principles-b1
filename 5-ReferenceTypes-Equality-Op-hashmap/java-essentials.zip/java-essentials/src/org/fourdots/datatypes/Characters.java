package org.fourdots.datatypes;

import java.io.UnsupportedEncodingException;
import java.nio.ByteOrder;
import java.nio.charset.Charset;

public class Characters {
	public static void printDefaults() {
		// Default encoding
		Charset defaultCharset = Charset.defaultCharset();
		System.out.println("Default Encoding: " + defaultCharset.displayName());

		// Byte Order
		ByteOrder endianness = ByteOrder.nativeOrder();
		if (endianness.equals(ByteOrder.BIG_ENDIAN)) {
			System.out.println("System is big-endian.");
		} else {
			System.out.println("System is little-endian.");
		}
	}

	public static void basics() {
		char c1 = 'A';
		char c2 = 'ä';
		char c3 = 'வ';
		char c4 = 0x0BB5;
		System.out.println("Character: " + c1 + ", " + c2 + ", " + c3 + ", " + c4);

//		char c5 = '🏃'; // Invalid character constant
		String s5 = "🏃";
		System.out.println("Emoji: " + s5);
	}

	public static byte[] getUtfBytes(char character, String utfType) {
		try {
			byte[] utfBytes;

			if (utfType.equals("UTF-8")) {
				utfBytes = String.valueOf(character).getBytes("UTF-8");
			} else if (utfType.equals("UTF-16")) {
				ByteOrder endianness = ByteOrder.nativeOrder();
				if (endianness.equals(ByteOrder.BIG_ENDIAN)) {
					utfBytes = String.valueOf(character).getBytes("UTF-16BE");
				} else {
					utfBytes = String.valueOf(character).getBytes("UTF-16LE");
				}
			} else {
				System.out.println("Invalid UTF type. Please specify 'UTF-8' or 'UTF-16'.");
				return null;
			}
			return utfBytes;
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return null;
		}
	}

	// Convert the character to bytes using UTF-8 encoding
	public static String getHex(char character, String utfType) {
		byte[] utf8Bytes = getUtfBytes(character, utfType);
		StringBuilder hexRepresentation = new StringBuilder();
		/**
		 * In UTF-8
		 * 
		 * Code points in the range U+0080 to U+07FF are represented using two bytes.
		 * Code points in the range U+0800 to U+FFFF are represented using three bytes.
		 * Code points in the range U+10000 to U+10FFFF are represented using four
		 * bytes.
		 */
		for (byte b : utf8Bytes) {
			hexRepresentation.append(String.format("%02X ", b));
		}
		return hexRepresentation.toString();

	}

	public static void analyze(String word, boolean detailed) {
		try {
			String myUnicodeChar = word;
			int numChars = myUnicodeChar.length();
			System.out.println(myUnicodeChar + " has " + numChars + " characters");

			byte[] utf8 = myUnicodeChar.getBytes("UTF-8");
			System.out.println("Number of bytes(UTF-8): " + utf8.length);

			byte[] utf16 = myUnicodeChar.getBytes("UTF-16");
			System.out.println("Number of bytes(UTF-16): " + utf16.length);

			if (detailed) {
				for (int i = 0; i < myUnicodeChar.length(); i++) {
					char character = myUnicodeChar.charAt(i);
					int codePoint = myUnicodeChar.codePointAt(i);

					// https://openjdk.org/jeps/280
					// https://www.baeldung.com/java-string-concatenation-methods
					System.out.println(
							"[" + i + "] = " + character + " = " + String.format("U+%04X", codePoint) + " = (UTF-8) "
									+ getHex(character, "UTF-8") + " = (UTF-16) " + getHex(character, "UTF-16"));

//					StringBuilder sb = new StringBuilder();
//					sb.append("[").append(i).append("]");
				}
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		printDefaults();
		// basics();

		// https://en.wikipedia.org/wiki/Plane_(Unicode)
		// https://home.unicode.org/
		String lang = "swedish";

		// Basic Multilingual Plane
		if (lang.contains("english")) {
			// English Characters
			// https://en.wikipedia.org/wiki/ASCII
			analyze("Welcome", true);
		}
		if (lang.contains("swedish")) {
			// Swedish Characters
			// https://en.wikipedia.org/wiki/ISO/IEC_8859-1
			analyze("Välkommen", true);
		}
		if (lang.contains("tamil")) {
			// Tamil Characters
			// https://en.wikipedia.org/wiki/Tamil_(Unicode_block)
			analyze("வரவேற்பு", true);
		}
		if (lang.contains("telugu")) {
			// Telugu Characters
			// https://en.wikipedia.org/wiki/Telugu_(Unicode_block)
			analyze("స్వాగతం", true);
		}
	}
}
