package org.y;

import org.x.Math;

public class MainApp {
  public static void main(String[] args) {
    int num1 = 10;
    int num2 = 20;
    int result = Math.sum(num1, num2);
    System.out.println("Sum via Math lib: " + result);
  }
}