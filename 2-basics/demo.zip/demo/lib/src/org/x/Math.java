package org.x;

public class Math {
  public static int sum(int a, int b) {
    return a + b;
  }

  public static void main(String[] args) {
    int num1 = 5;
    int num2 = 7;
    int result = sum(num1, num2);
    System.out.println("Sum: " + result);
  }
}